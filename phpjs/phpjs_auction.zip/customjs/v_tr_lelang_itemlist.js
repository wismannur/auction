$(document).ready(function() {
    // for show the loading
    // $('body').addClass('loaded');
    $('body').removeClass('loaded');

    $('[data-name="row_id"]').hide()
    $('[data-phrase="ButtonExport"]').closest('button').hide()
    $('[data-name="bid_val"]').css({'width' : '150px'})
    $('[data-name="bid_step"]').hide()
    $('[data-name="open_bid"]').hide()

    window.auc_status = $('#auc_status').find('span > span').text().slice(1);
    window.countDown_first = 1;
    window.difference_days_start_bid = 0;
    window.row_id_lelang_item = $('#row_id_lelang_item').find('span > span').text().slice(1);

    function startCloseBid(nameClass, when) {
        var bid = $(nameClass).find('span')
        var bid_text = bid.find('span').text().split(' ')
        var bid_date = bid_text[0].split('/')
        var bid_time = bid_text[1]
        var get_date_bid = convertDate(bid_date[0].slice(1), bid_date[1], bid_date[2])
        bid.find('span').html(get_date_bid)
        bid.eq(0).append('<br><span>'+ bid_time +'</span>')

        if (when == 'start') {
            window.start_bid = bid_date;
        } else if (when == 'close') {
            window.close_bid = bid_date;
        }

    }

    function daysDifference(d0, d1) {
        var diff = new Date(+d1).setHours(12) - new Date(+d0).setHours(12);
        return Math.round(diff/8.64e7);
    }

    function differenceDays(yy, mm, dd) {
        n =  new Date();
        y = n.getFullYear();
        m = n.getMonth() + 1;
        d = n.getDate();

        let hasil = daysDifference(new Date(y,m,d), new Date(yy, mm, dd))
                
        return hasil;
    };

    function getLastBid(id, lastBid_list) {
        if (auc_status == '0' || auc_status == '1') {
            $.ajax({
                type : 'GET',
                url : 'run_sql.php',
                data : {
                    as : 'json',
                    db : 'db_tea_auction',
                    sql : 'SELECT bid_value FROM tr_bid WHERE master_id = '+ id +' ORDER BY row_id DESC LIMIT 1'
                },
                success: function(data) {
                    if (data != "0 results") {
                        window.hasil = JSON.parse(data)
                        lastBid_list.find('span > span').html( numberWithCommas(hasil[0].bid_value) )
                    } 
                    // console.log('get last bid', data)
                }
            })
        }
    };

    function getLastHighestBid(id, highBid_list) {
        if (auc_status == '0' || auc_status == '1') {
            $.ajax({
                type : 'GET',
                url : 'run_sql.php',
                data : {
                    as : 'json',
                    db : 'db_tea_auction',
                    sql : 'SELECT MAX(bid_value), user_id FROM tr_bid WHERE master_id = '+ id +''
                },
                success: function(data) {
                    if (data != "0 results") {
                        let hasil_highBid_list = JSON.parse(data)
                        highBid_list.find('span > span').html( numberWithCommas(hasil_highBid_list[0]['MAX(bid_value)']) )
                    } 
                    // console.log('get last highest bid', data)
                }
            })
        }
    }

    function reqSampleDone(id, req_sample_list) {
        $.ajax({
            type : 'GET',
            url : 'run_sql.php',
            data : {
                as : 'json',
                db : 'db_tea_auction',
                sql : 'SELECT row_id FROM tr_req_sample WHERE user_id='+ userID +' AND master_id='+ id +''
            },
            success: function(data) {
                // console.log(data)
                if (data[0] != "0") {
                    req_sample_list.find('span > div > a').removeClass('btn-primary')
                    req_sample_list.find('span > div > a').addClass('btn-success')
                    req_sample_list.find('span > div > a').removeAttr('data-target')
                    req_sample_list.find('span > div > a').html('Request Done')
                    req_sample_list.find('span > div > a').removeAttr('onclick')
                }
            }
        })
    }

    window.populateTable = function(status) {
        // console.log(status)
        let jumlahField = totalField('#tbl_v_tr_lelang_itemlist')
        var tbl_lelang_item = $('#tbl_v_tr_lelang_itemlist').find('tbody tr')
        for (let i = 0; i < jumlahField; i++) {
            let checkDataIndex = tbl_lelang_item.eq(i).attr('data-rowindex')
            // let enterBid_list = $('#tbl_v_tr_lelang_itemlist').find('tbody tr').eq(i).find('[data-name="enter_bid"]')
            let highBid_list = tbl_lelang_item.eq(i).find('[data-name="highest_bid"]')
            let lastBid_list = tbl_lelang_item.eq(i).find('[data-name="last_bid"]')
            let req_sample_list = tbl_lelang_item.eq(i).find('[data-name="req_sample"]')
            let auction_status_list = tbl_lelang_item.eq(i).find('[data-name="auction_status"]')
            let id_list = tbl_lelang_item.eq(i).find('[data-name="row_id"]')    
            if (checkDataIndex != "$rowindex$" ) {
                let get_id = id_list.find('span > span').text().slice(1)
                reqSampleDone(get_id, req_sample_list)
                if (status == '0' || status == '1') {
                    // console.log('terpanggil')
                    getLastBid(get_id, lastBid_list)
                    getLastHighestBid(get_id, highBid_list)
                }

                let state_auc = auction_status_list.find('span > span')
                if (state_auc.text().slice(1) == 'Opened') {
                    state_auc.addClass('auc_status_opened')
                } else if (state_auc.text().slice(1) == 'WD') {
                    state_auc.addClass('auc_status_wd')
                } else if (state_auc.text().slice(1) == 'Sold') {
                    state_auc.addClass('auc_status_sold')
                } 
                // else {
                //     state_auc.html('-')
                // }
            }
        }
    }

    // Called after form input is processed
    function startConnect() {
        // Generate a random client ID
        clientID = "clientID-" + parseInt(Math.random() * 100);

        // Fetch the hostname/IP address and port number from the form
        host = "broker.hivemq.com";
        port = 8000;

        // Initialize new Paho client connection
        client = new Paho.MQTT.Client(host, Number(port), clientID);

        // Set callback handlers
        client.onConnectionLost = onConnectionLost;
        client.onMessageArrived = onMessageArrived;

        // Connect the client, if successful, call onConnect function
        client.connect({ 
            onSuccess: onConnect,
        });
    }

    // Called when the client connects
    function onConnect() {
        // Fetch the MQTT topic from the form
        topic = "mqtt/new/bid";

        // Print output for the user in the messages div
        console.log("[read.html] Subscribing to: " + topic);

        // Subscribe to the requested topic
        client.subscribe(topic);
    }

    // Called when the client loses its connection
    function onConnectionLost(responseObject) {
        console.log("[read.html] ERROR: Connection lost");
        if (responseObject.errorCode !== 0) {
            $('.custom_message_lost').show();
            console.log("[read.html] ERROR: " + responseObject.errorMessage );
        }
    }

    // Called when a message arrives
    function onMessageArrived(message) {
        console.log("[read.html] onMessageArrived: " + message.payloadString);
        if(message.payloadString == "query")
        {
            populateTable(auc_status);
            console.log("[read.html] Sending query request...");
        }
    }

    // Called when the disconnection button is pressed
    function startDisconnect() {
        client.disconnect();
        console.log('Connection server disconnect')
        // document.getElementById("messages").innerHTML += '<span>Disconnected</span><br/>';
    }

    window.getRowID = function (id) {
        window.row_id = id;
    }

    window.addBid = function (eq, id) {
        let c = $('#bid_value_' + eq).val()

        let obj = {
            master_id : "" + id + "",
            bid_time : dateNow + " " + $('#time_lelang_bid').text(),
            bid_value : $('#bid_value_' + eq).val().split(',').join(''),
            user_id : userID,
            db : 'db_tea_auction'
        }

        function addNewBid(obj) {
            let sql = "INSERT INTO tr_bid (master_id, bid_time, bid_value, user_id) VALUES ('"+ obj.master_id +"', '"+ obj.bid_time +"', '"+ obj.bid_value +"', '"+ obj.user_id +"')";
            $.ajax({
                type : 'POST',
                url : 'run_sql_insert.php',
                data : {
                    sql : sql,
                    db : obj.db
                },
                success: function(data) {
                    console.log(data)
                    setTimeout(function() {
                        toastr.success("BID BERHASIL NILAI "+ c +"");
                    }, 2000)
                }
            })
        }

        let lastHighest_bid = $('#highest_bid_'+ eq + '').text().split(',').join('')
        if (parseFloat(c) < parseFloat(lastHighest_bid)) {
            toastr.error("NILAI BID LEBIH KECIL DARI HIGHEST BID TERAKHIR");
            $('#bid_value_'+ eq + '').addClass('input-error');
            // debugger
        } else {
            $('#bid_value_'+ eq + '').removeClass('input-error');
            let sql = "UPDATE tr_lelang_item SET last_bid='"+ obj.bid_value +"' WHERE row_id='"+ id +"'";
            $.ajax({
                type: 'POST',
                url : 'run_sql_insert.php',
                data : {
                    sql : sql,
                    db : obj.db
                },
                success: function(data) {
                    console.log(data)
                    addNewBid(obj)
                }
            })
        }

    }

    window.getReqSample = function (id, eq) {
        window.row_id = id;
        window.req_sample_eq = eq;
        $('#addReqSample').show();
        $('#cancelReqSample').html('Cancel');
    }

    window.addReqSample = function () {
        $('.spinner_req').show();
        $('#addReqSample').attr('disabled', 'disabled');
        let req_sample_list = $('#tbl_v_tr_lelang_itemlist').find('tbody tr').eq(req_sample_eq).find('[data-name="req_sample"]')

        let obj = {
            master_id : "" + row_id + "",
            req_date : dateNow + " " + $('#time_lelang_bid').text(),
            user_id : userID,
            db : 'db_tea_auction'
        }

        let sql = "INSERT INTO tr_req_sample (master_id, req_date, user_id) VALUES ('"+ obj.master_id +"', '"+ obj.req_date +"', '"+ obj.user_id +"')";

        $.ajax({
            type : 'POST',
            url : 'run_sql_insert.php',
            data : {
                sql : sql,
                db : obj.db
            },
            success: function(data) {
                console.log(data)
                reqSampleDone(row_id, req_sample_list)
                $('.success-req-sample').show()
                $('#addReqSample').hide()
                $('.spinner_req').hide();
                $('#cancelReqSample').html('Close')
                setTimeout(function() {
                    $('.close').click();
                    $('.success-req-sample').hide();
                    $('#addReqSample').removeAttr('disabled');
                }, 3000)
            }
        })
    }

    function calculateRow(status){
        console.log(status)
        let jumlahField = totalField('#tbl_v_tr_lelang_itemlist')
        var tbl_lelang_item = $('#tbl_v_tr_lelang_itemlist').find('tbody tr')
		for(let i = 0; i < jumlahField; i++){
            let checkDataIndex = tbl_lelang_item.eq(i).attr('data-rowindex')
            let enterBid_list = tbl_lelang_item.eq(i).find('[data-name="enter_bid"]')
            let lastBid_list = tbl_lelang_item.eq(i).find('[data-name="last_bid"]')
            let highBid_list = tbl_lelang_item.eq(i).find('[data-name="highest_bid"]')
            let bid_val = tbl_lelang_item.eq(i).find('[data-name="bid_val"]')
            let bid_step_list = tbl_lelang_item.eq(i).find('[data-name="bid_step"]')
            let open_bid_list = tbl_lelang_item.eq(i).find('[data-name="open_bid"]')
            let bid_list = tbl_lelang_item.eq(i).find('[data-name="btn_bid"]')
            let req_sample_list = tbl_lelang_item.eq(i).find('[data-name="req_sample"]')
            let sack_list = tbl_lelang_item.eq(i).find('[data-name="sack"]')
            let netto_list = tbl_lelang_item.eq(i).find('[data-name="netto"]')
            let gross_list = tbl_lelang_item.eq(i).find('[data-name="gross"]')
            let auction_status_list = tbl_lelang_item.eq(i).find('[data-name="auction_status"]')
            let winner_bid_list = tbl_lelang_item.eq(i).find('[data-name="winner_id"]')
            let id_list = tbl_lelang_item.eq(i).find('[data-name="row_id"]')
            if (checkDataIndex != "$rowindex$" ) {
                enterBid_list.css({'text-align': 'center'})
                lastBid_list.css({'text-align': 'right'})
                highBid_list.css({'text-align': 'right'})
                winner_bid_list.css({'text-align': 'center'})
                bid_list.css({'text-align': 'center'})
                req_sample_list.css({'text-align': 'center'})
                sack_list.css({'text-align': 'right'})
                netto_list.css({'text-align': 'right'})
                gross_list.css({'text-align': 'right'})
                auction_status_list.css({'padding': '10px 5px'})

                let val_bid_step = bid_step_list.find('span > span').text().slice(1);
                let val_open_bid = open_bid_list.find('span > span').text().slice(1);
                let first_val_bid = parseFloat(val_bid_step) + parseFloat(val_open_bid);
                var bid_val_input = `<div class="input-group" >
                        <input type="" id="bid_value_`+ i +`" class="input-bid mod" value="`+ numberWithCommas(first_val_bid) +`"><span class="input-group-btn">
                            <button id="bidUp_`+ i +`" type="button" class="btn btn-primary btn-sm" style="font-size: 11px; height: 15.5px; padding: 0 10px;">
                                <i class="fa fa-angle-up" aria-hidden="true"></i>
                            </button><br>
                            <button id="bidDown_`+ i +`" type="button" class="btn btn-success btn-sm" style="font-size: 11px; height: 15.5px; padding: 0 10px;">
                                <i class="fa fa-angle-down" aria-hidden="true"></i>
                            </button>
                        </span>
                    </div>`;
                bid_val.find('span > span').remove()

                var id_lelang_item = id_list.find('span > span').text().slice(1)
                var btn_bid = `
                    <div class="spinner-border text-danger spinner_bid_`+i+`" role="status" style="display: none; margin-right: 10px;">
                        <span class="sr-only">Loading...</span>
                    </div>
                <div class="btn-group" data-original-title="" title=""><a class="btn-sm ewRowLink ewDetail btn btn-lg btn-danger"><i class="fa fa-usd" aria-hidden="true"></i> Bid&nbsp;</a></div>`
                bid_list.find('span > span').remove()

                var btn_req_sample = '<div class="btn-group" data-original-title="" title=""><a class="btn-sm ewRowLink ewDetail btn btn-lg btn-primary" data-toggle="modal" data-target="#modalReqSample" onclick="getReqSample('+ id_lelang_item +', '+ i +')">Request Sample&nbsp;</a></div>'
                req_sample_list.find('span > span').remove()

                if (bid_val.find('span > div').length == 0) {
                    bid_val.find('span').append(bid_val_input)
                    bid_list.find('span').append(btn_bid)
                    req_sample_list.find('span').append(btn_req_sample)
                }

                if (status == '-1') {
                    bid_list.find('span > div > a').attr('disabled', 'disabled')
                    bid_val.find('span > div > span > button').attr('disabled', 'disabled')
                    lastBid_list.find('span > span').html('-')
                    highBid_list.find('span > span').html('-')
                    winner_bid_list.find('span > span').html('-')
                    $('#bid_value_'+ i).addClass('form-control').attr('readonly', 'readonly')
                } else if (status == '0') {
                    bid_list.find('span > div > a').attr('onclick', 'addBid('+ i +' ,'+ id_lelang_item +')')
                    bid_list.find('span > div > a').removeAttr('disabled')
                    bid_val.find('span > div > span > button').removeAttr('disabled', 'disabled')
                    highBid_list.find('span > span').attr('id', 'highest_bid_' + i + '')
                    winner_bid_list.find('span > span').html('-')
                    $('#bid_value_'+ i).removeClass('form-control').removeAttr('readonly')
                    bidUpDown(i, bid_step_list)
                } 

			} else {
				console.log('NOT eksekusi = ' + checkDataIndex)
            }
            
            if (difference_days_start_bid < 7) {
                console.log(difference_days_start_bid, 'kurang tujuh hari')
                req_sample_list.find('span > div > a').removeAttr('onclick')
                req_sample_list.find('span > div > a').removeAttr('data-target')
                req_sample_list.find('span > div > a').removeAttr('data-toggle')
                req_sample_list.find('span > div > a').attr('disabled', 'disabled')
            }
		}
    };

    function bidUpDown(eq , bid_step_list) {
        var open_bid = bid_step_list.find('span > span').text().slice(1);

        function checkCorrectBid(bid) {
            let lastHighest_bid = $('#highest_bid_'+ eq + '').text().split(',').join('')
            if (parseFloat(bid) < parseFloat(lastHighest_bid || bid <= 0)) {
                $('#bid_value_'+ eq + '').addClass('input-error');
            } else {
                $('#bid_value_'+ eq + '').removeClass('input-error');
            }
        }

        $('#bidUp_' + eq).on('click', function() {
            let bid_value = $('#bid_value_' + eq).val().split(',').join('');
            let hasil = parseFloat(bid_value) + parseFloat(open_bid);
            console.log(hasil)
            if (hasil == 0) {
                $('#bid_value_' + eq).val( 0 )
            } else {
                $('#bid_value_' + eq).val( numberWithCommas(hasil) )
            }

            checkCorrectBid(bid_value)
        })

        $('#bidDown_' + eq).on('click', function() {
            let bid_value = $('#bid_value_' + eq).val().split(',').join('');
            let hasil = parseFloat(bid_value) - parseFloat(open_bid) ;
            console.log(hasil)
            if (hasil == 0) {
                $('#bid_value_' + eq).val( 0 )
            } else {
                $('#bid_value_' + eq).val( numberWithCommas(hasil) )
            }

            checkCorrectBid(bid_value)
        })

        $('#bid_value_' + eq).on('keyup', function() {
            let getValueBid = $(this).val().split(',').join('')
            let hasil = numberWithCommas(getValueBid)
            $(this).val(hasil)
            
            checkCorrectBid(getValueBid)
        })
    }

    $('#cancelReqSample').on('click', function() {
        $('.spinner_req').hide();
        $('.success-req-sample').hide();
        $('#addReqSample').removeAttr('disabled');
    })

    function checkTime(i) {
        if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
        return i;
    }
    function startTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        m = checkTime(m);
        s = checkTime(s);
        $('#time_lelang').html(h + ":" + m + ":" + s)
        var t = setTimeout(function() {
            startTime()
        }, 500);

        n =  new Date();
        y = n.getFullYear();
        m = monthNames[n.getMonth()];
        d = n.getDate();
        $('#date_lelang').html(d + " - " + m + " - " + y)
        window.dateNow = y +"-"+ (n.getMonth() + 1) +"-"+ d;
    }

    function convertDate(date, month, year) {
        if (month.slice(0,1) == 0) {
            month = month.slice(1) - 1
        } else if (month.slice(0,1) == 1) {
            month = month - 1
        }

        let d = date
        let m = monthNames[month];
        let y = year
        var hasil = d + " - " + m + " - " + y;
        return hasil;
    }

    function convertItemIdr(nameClass) {
        var item = $(nameClass).find('span > span')
        var item_text = item.text()
        var getFormatIdr = numberWithCommas(item_text)
        if (getFormatIdr.split('.').length == 1) {
            item.html(getFormatIdr + '.00')
        } else if (getFormatIdr.split('.').length == 2) {
            item.html(getFormatIdr)
        }
    }

    function winnerBid(id, user_id, winner_bid_list) {

        function getFullName(user_id) {
            $.ajax({
                type : 'GET',
                url : 'run_sql.php',
                data : {
                    as : 'json',
                    db : 'db_tea_auction',
                    sql : 'SELECT FullName FROM members WHERE user_id = '+ user_id +''
                },
                success: function(data) {
                    let hasil = JSON.parse(data)
                    winner_bid_list.find('span > span').html(hasil[0].FullName)
                    console.log('ini hasil full name = ', hasil)
                }
            })
        }

        $.ajax({
            type: 'POST',
            url : 'run_sql_post.php',
            data : {
                as : 'json',
                db : 'db_tea_auction',
                sql : "UPDATE tr_lelang_item SET winner_id="+ user_id +" WHERE row_id='"+ id +"'"
            },
            success: function(data) {
                console.log(data)
                getFullName(user_id)
            }
        })
    }

    function stateBid(id, status, auction_status_list) {
        $.ajax({
            type: 'POST',
            url : 'run_sql_insert.php',
            data : {
                as : 'json',
                db : 'db_tea_auction',
                sql : "UPDATE tr_lelang_item SET auction_status="+ status +" WHERE row_id='"+ id +"'"
            },
            success: function(data) {
                console.log(data)

                let state_auc = auction_status_list.find('span > span')
                if (status == '1') {
                    state_auc.addClass('auc_status_wd')
                    state_auc.html('WD')
                } else {
                    state_auc.addClass('auc_status_sold')
                    state_auc.html('Sold')
                }
            }
        })
    }

    function addHighestBid(id, highest_bid_val) {
        $.ajax({
            type: 'POST',
            url : 'run_sql_insert.php',
            data : {
                as : 'json',
                db : 'db_tea_auction',
                sql : "UPDATE tr_lelang_item SET highest_bid='"+ highest_bid_val +"', sold_bid='"+ highest_bid_val +"' WHERE row_id='"+ id +"'"
            },
            success: function(data) {
                console.log(data)
            }
        })
    }

    function getHighestBid(id, highBid_list, bid_step_list, auction_status_list, winner_bid_list) {
        $.ajax({
            type : 'GET',
            url : 'run_sql.php',
            data : {
                as : 'json',
                db : 'db_tea_auction',
                sql : 'SELECT MAX(bid_value), user_id FROM tr_bid WHERE master_id = '+ id +''
            },
            success: function(data) {
                window.hasil = JSON.parse(data)
                let nilai_bid = hasil[0]["MAX(bid_value)"]
                let user_id = hasil[0]["user_id"]
                if (nilai_bid != null) {
                    let open_bid = bid_step_list.find('span > span').text().slice(1);
                    console.log(hasil)
                    
                    highBid_list.find('span > span').html(nilai_bid)
                    addHighestBid(id, nilai_bid)
                    winnerBid(id, user_id, winner_bid_list)
                    if (parseFloat(nilai_bid) >= parseFloat(open_bid)) {
                        stateBid(id, "2", auction_status_list)
                    } else if (parseFloat(nilai_bid) <= parseFloat(open_bid)) {
                        stateBid(id, "1", auction_status_list)
                    }
                } else {
                    console.log(data)
                }
            }
        })
    }

    function setProforma(jumlah, id) {
        $.ajax({
            type: 'POST',
            url : 'run_sql_insert.php',
            data : {
                as : 'json',
                db : 'db_tea_auction',
                sql : "UPDATE tr_lelang_item SET proforma_amount='"+ jumlah +"', proforma_number='"+ id +"' WHERE row_id='"+ id +"'"
            },
            success: function(data) {
                console.log(data)
            }
        })
    }

    function allCloseBid() {
        let jumlahField = totalField('#tbl_v_tr_lelang_itemlist')
        var tbl_lelang_item = $('#tbl_v_tr_lelang_itemlist').find('tbody tr')
        for (let i = 0; i < jumlahField; i++) {
            let checkDataIndex = tbl_lelang_item.eq(i).attr('data-rowindex')
            let sack_list = tbl_lelang_item.eq(i).find('[data-name="sack"]')
            let gross_list = tbl_lelang_item.eq(i).find('[data-name="gross"]')
            let highBid_list = tbl_lelang_item.eq(i).find('[data-name="highest_bid"]')
            let bid_step_list = tbl_lelang_item.eq(i).find('[data-name="bid_step"]')
            let lastBid_list = tbl_lelang_item.eq(i).find('[data-name="last_bid"]')
            let auction_status_list = tbl_lelang_item.eq(i).find('[data-name="auction_status"]')
            let winner_bid_list = tbl_lelang_item.eq(i).find('[data-name="winner_id"]')
            let id_list = tbl_lelang_item.eq(i).find('[data-name="row_id"]')    
            if (checkDataIndex != "$rowindex$" ) {
                if (auc_status != '1') {
                    // lastBid_list.find('span > span').html('-')
                }
                let get_id = id_list.find('span > span').text().slice(1)
                getHighestBid(get_id, highBid_list, bid_step_list, auction_status_list, winner_bid_list)
                let val_sack = sack_list.find('span > span').text().slice(1).split(',').join('')
                let val_gross = gross_list.find('span > span').text().slice(1).split(',').join('')
                let val_highestBid = highBid_list.find('span > span').text().slice(1).split(',').join('')
                let amount_p = (parseFloat(val_sack) * parseFloat(val_gross) * parseFloat(val_highestBid))
                console.log(amount_p)
                
                // setProforma( numberWithCommas(amount_p), get_id)
            }
        }
    }

    function changeAucStatus(val) {
        let obj = {
            id : row_id_lelang_item,
            auc_status : val,
            db : 'db_tea_auction'
        }

        let sql = "UPDATE tr_lelang_master SET auc_status='"+ obj.auc_status +"' WHERE row_id='"+ obj.id +"'";
        $.ajax({
            type: 'POST',
            url : 'run_sql_insert.php',
            data : {
                sql : sql,
                db : obj.db
            },
            success: function(data) {
                console.log(data)
                if (auc_status == '-1') {
                    auc_status = '0'
                    loadDataFirst()
                } else if (auc_status == '0') {
                    auc_status = '1'
                    loadDataFirst()
                }
            }
        })
    }

    // Update the count down every 1 second
    var x = setInterval(function() {
        // Set the date we're counting down to
        let close_date = $('#el_v_tr_lelang_master_start_bid').find('span').eq(0).text().split(' ').join('');
        let close_time = $('#el_v_tr_lelang_master_start_bid').find('span').eq(1).text()
        let close_date_time = close_date + ' ' + close_time;
        var countDownDate = new Date(close_date_time).getTime();
        // var countDownDate = new Date("19-Mar-2019 14:39:00").getTime();

        // Get todays date and time
        var now = new Date().getTime();
            
        // Find the distance_first between now and the count down date
        window.distance_first = countDownDate - now;
            
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance_first / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance_first % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance_first % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance_first % (1000 * 60)) / 1000);
            
        // Output the result in an element with id="demo"
        $('#countDown').find('span').html( days + " Hari | " + hours + ":" + minutes + ":" + seconds )
        $('.custom-width-4').css({'border': '3px solid yellow'}); 
        $('.custom-width-4').find('.tittle-v-tr-lelang-item').html('Remaining Start')

        // If the count down is over, write some text 
        if (distance_first < 0) {
            countDown_first = 0;
            if (auc_status == '-1') {
                changeAucStatus('0')
            }
            clearInterval(x);
        }       
    }, 1000);

    var y = setInterval(function() {
        // Set the date we're counting down to
        let close_date = $('#el_v_tr_lelang_master_close_bid').find('span').eq(0).text().split(' ').join('');
        let close_time = $('#el_v_tr_lelang_master_close_bid').find('span').eq(1).text()
        let close_date_time = close_date + ' ' + close_time;
        var countDownDate = new Date(close_date_time).getTime();
        // var countDownDate = new Date("19-Mar-2019 14:39:00").getTime();

        // Get todays date and time
        var now = new Date().getTime();
            
        // Find the distance_last between now and the count down date
        window.distance_last = countDownDate - now;
            
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance_last / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance_last % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance_last % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance_last % (1000 * 60)) / 1000);
            
        // Output the result in an element with id="demo"
        if (countDown_first == 0) {
            $('#countDown').find('span').html( days + " Hari | " + hours + ":" + minutes + ":" + seconds )
            $('.custom-width-4').css({'border': '3px solid green'}); 
            $('.custom-width-4').find('.tittle-v-tr-lelang-item').html('Time Left')
        }
        
        // If the count down is over, write some text 
        if (distance_last < 0) {
            if (auc_status == '0') {
                $('body').removeClass('loaded');
                startDisconnect()
                changeAucStatus('1')
                allCloseBid()
            }

            clearInterval(y);
            $('.custom-width-4').css({'border': '3px solid red'}); 
            $('#countDown').find('span').html("<h4 style='font-weight: bold; text-transform: uppercase; color: red;' >closed</h4>");
        }       
    }, 1000);

    function loadDataFirst() {
        if (auc_status == '-1') {
            calculateRow(auc_status)
            populateTable(auc_status)
            // startConnect();
            setTimeout(function() {
                $('body').addClass('loaded');
            }, 3500);
        } else if (auc_status == '0') {
            calculateRow(auc_status)
            startConnect();
            setTimeout(function() {
                populateTable(auc_status);
                $('body').addClass('loaded');
            }, 3500);
        } else if (auc_status == '1') {
            calculateRow(auc_status)
            setTimeout(function() {
                populateTable(auc_status);
                $('body').addClass('loaded');
            }, 3500);
            $('[data-name="bid_val"]').remove();
            $('[data-name="btn_bid"]').remove();
        }
    }
    
    startCloseBid('.start-bid-v-tr-lelang-item', 'start')
    startCloseBid('.close-bid-v-tr-lelang-item', 'close')
    difference_days_start_bid = differenceDays(start_bid[2], start_bid[1], start_bid[0].slice(1))
    loadDataFirst()
    getUserID();
    startTime()
    convertItemIdr('.sack-item')
    convertItemIdr('.gross-item')
    // convertItemIdr('.netto-item')
    
    
})