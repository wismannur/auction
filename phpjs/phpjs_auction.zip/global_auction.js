$(document).ready(function() {
    // this is for add custom tittle navbar
    var custom_nav = '<h5 class="nav-title">PT. KABEPE CHAKRA</h5>'
    $(custom_nav).insertBefore('.navbar-custom-menu')
})

// this is for create number with separator comma
function numberWithCommas(x) {
    if (x == 0 || x == "↵") {
        return 0
    } else if (x !== "") {
        let e = x.toString().split('')
        e[0] == '0' ? e = e.slice(1).join('') : '' ;
        let f = e.toString().split(',').join('')
        let y = f.toString().split('.')
        if (y.length == 2) {
            var a = y[0]
            var b = y[1].slice(0,2)
            // console.log('dari result commas = ' + a + ' . ' + b)
            return a.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + '.' + b;
        } else if (y.length == 1) {
            return y[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    } else {
        return 0
    }
}

// this is for get data by url
function getDataUrl(data) {
    let lengthDataUrl = window.location.search.split('&').length
    for (let i = 0; i < lengthDataUrl; i++) {
        let checkDataUrl = window.location.search.split('&')[i].split('=')[0]
        var dataUrl = ''
        i == 0 ? dataUrl = checkDataUrl.slice(1) : dataUrl = checkDataUrl ;
        if (data == dataUrl) {
            let result = window.location.search.split('&')[i].split('=')[1]
            return result
        }
    }
}

// this is for change to be width 100% input
function responsiveWidthTable() {
    $('.ewTableRow').find('td > span').css({'width':'100%'})
    $('.ewTableRow').find('td > span > input').css({'width':'100%'})
    $('.ewTableRow').find('td > span > span > span > input').css({'width':'100%'})
    $('.ewTableRow').find('td > span > div').css({'width':'100%'})
    $('.ewTableRow').find('td > .btn-group.ewButtonGroup').css({'text-align':'center', 'display': 'block' })
    $('.ewTableAltRow').find('td > span').css({'width':'100%'})
    $('.ewTableAltRow').find('td > span > input').css({'width':'100%'})
    $('.ewTableAltRow').find('td > span > span > span > input').css({'width':'100%'})
    $('.ewTableAltRow').find('td > span > div').css({'width':'100%'})
    $('.ewTableAltRow').find('td > .btn-group.ewButtonGroup').css({'text-align':'center', 'display': 'block' })
}

// this is for count total row in table detail
function totalField(nameTable) {
    let jumlahField = $(nameTable).find('tbody tr').length
    return jumlahField
};

function addCustomJS(nameJS) {
	let takeJS = "";
	if (nameJS.slice(-3) == "add") {
		takeJS = nameJS.slice(0, -3)
	} else if (nameJS.slice(-4) == "edit") {
		takeJS = nameJS.slice(0, -4)
	} else {
        takeJS = nameJS;
    }

	$('section.content').append("<script type='text/javascript' src='phpjs/customjs/" + takeJS +".js'></script>")
};

window.monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ];
window.userID = "";

function getUserID() {
    let username = $('.user-body').find('p').text().slice(2);
    $.ajax({
        type: 'GET',
        url : 'run_sql.php',
        data : {
            as: 'json',
            db : 'db_tea_auction',
            sql : 'SELECT user_id FROM members WHERE username = "'+ username +'"',
        }, 
        success: function(data) {
            let result = JSON.parse(data);
            userID = result[0].user_id;
        }
    });
}

setTimeout(function() {
    getUserID();
}, 2000)
